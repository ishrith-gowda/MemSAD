# Reproducing MEMSAD

This supplementary material accompanies the NeurIPS 2026 submission and contains
the full implementation, evaluation harness, synthetic corpus, and result
artifacts used to produce every table and figure in the main paper.

## Environment

- Python 3.11+ (also tested on 3.10 and 3.13)
- `pip install -r requirements.txt`
- No GPU required. Full pipeline runs on CPU in ~5 minutes on a 2023 laptop.

## Quick reproduction (every paper result)

```bash
python -m src.scripts.run_pipeline --output-dir ./out
```

Regenerates Table 2 (3 x 5 attack-defense matrix), Table 3 (defense TPR/FPR),
Tables 4-6 (ablations), Tables 17-21 (encoder generalization, NQ cross-corpus,
compound exposure, tool-use, Mem0 production), and the corresponding figures.

## Per-result reproduction

| Paper result | Command |
|---|---|
| Table 2 (3 x 5 attack-defense matrix) | `python -m src.evaluation.attack_defense_matrix` |
| Table 3 (defense TPR / FPR) | `python -m src.evaluation.comprehensive_eval` |
| Tables 4-6 (ablations) | `python -m src.evaluation.ablation_study` |
| Encoder generalization (Table 17) | `python -m src.scripts.encoder_generalization` |
| NQ cross-corpus (Table 18) | `python -m src.scripts.nq_evaluation` |
| Compound exposure (Table 19) | `python -m src.evaluation.compound_exposure` |
| Tool-use agent (Table 20) | `python -m src.evaluation.agent_eval` |
| Mem0 production (Table 21) | `python -m src.scripts.run_phase28_experiments` |
| SIR multi-agent simulation (Fig. 10) | `python -m src.scripts.generate_sir_simulation` |
| LaTeX tables | `python -m src.scripts.generate_tables` |

## Tests

```bash
pytest src/tests/ -q
```

The full suite is 593 tests, deterministic, exits 0.

## Data

- `data/synthetic_corpus.json` -- 1,000 synthetic memory entries across 7 categories
- `data/victim_queries.json` -- 20 victim queries used for triggered calibration
- `data/nq_subset.json` -- Natural Questions cross-corpus replication set
- (If a data file is absent, it is regenerated on first run from the seeded
  generators in `src/data/`.)

## Notes for reviewers

- The OpenAI tool-use evaluation requires `OPENAI_API_KEY` and access to
  `gpt-4o-mini`; if absent, that single script (Table 20) is skipped.
  Every other table and figure is fully deterministic and offline.
- Randomness is seeded via `numpy.random.default_rng(42)` and equivalent
  PyTorch / Python seeds in each entry point; results are bit-reproducible
  across runs on the same Python version.
- Hardware-dependent timings reported in the paper (~2 ms per memory entry
  for MEMSAD) were measured on a 2023 commodity laptop; absolute numbers
  may differ on reviewer hardware but relative comparisons hold.

## License

MIT.
